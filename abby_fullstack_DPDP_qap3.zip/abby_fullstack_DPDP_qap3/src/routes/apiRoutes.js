// apiRoutes.js
const express = require('express');
const router = express.Router();

// Import your data access layer
const database = require('../dataAccess/database');

// Define API routes
router.get('/books', async (req, res) => {
  try {
    // Get all books from the database using the data access layer function
    const books = await database.getAllBooks();
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching books from the database.' });
  }
});

// Define other API routes (POST, PUT, PATCH, DELETE)

module.exports = router;
