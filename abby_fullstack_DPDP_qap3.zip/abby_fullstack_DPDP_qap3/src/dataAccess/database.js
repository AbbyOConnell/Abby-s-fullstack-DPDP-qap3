// database.js
const { Pool } = require('pg');

// Configure the PostgreSQL connection
const pool = new Pool({
  user: 'your_db_user',
  host: 'localhost',
  database: 'library',
  password: 'your_db_password',
  port: 5432,
});

module.exports = {
  // Implement your data access layer functions here
  async getAllBooks() {
    const query = 'SELECT * FROM book';
    const { rows } = await pool.query(query);
    return rows;
  },
  // Implement other data access layer functions (INSERT, UPDATE, DELETE)
};
