//task 1
CREATE TABLE author (
  author_id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  nationality VARCHAR(50)
);

CREATE TABLE genre (
  genre_id SERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL
);

CREATE TABLE book (
  book_id SERIAL PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author_id INT REFERENCES author(author_id),
  genre_id INT REFERENCES genre(genre_id),
  publication_year INT
);

//task 2:
SELECT * FROM book;

SELECT * FROM book WHERE genre_id = 1;

SELECT * FROM book WHERE author_id = 2;