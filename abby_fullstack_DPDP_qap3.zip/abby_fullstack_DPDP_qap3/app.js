// app.js
const express = require('express');
const methodOverride = require('method-override');
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));

// Define your routes
const apiRoutes = require('./src/routes/apiRoutes');
app.use('/api', apiRoutes);

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
