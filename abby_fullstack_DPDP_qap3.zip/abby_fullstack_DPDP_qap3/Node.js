const express = require('express');
const app = express();
const path = require('path');

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Set the views directory to the "views" folder
app.set('views', path.join(__dirname, 'views'));

// Sample books data (replace this with data from the database)
const books = [
  { title: 'Book 1', author_id: 1, genre_id: 1, publication_year: 2020 },
  { title: 'Book 2', author_id: 2, genre_id: 2, publication_year: 2018 },
  // Add more books here
];

// Route to render the index.ejs template with the books data
app.get('/', (req, res) => {
  res.render('index', { books: books });
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
